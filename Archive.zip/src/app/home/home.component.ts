import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
// @Component({templateUrl: 'home.component.html'})
export class HomeComponent implements OnInit {
 displayedColumns: string[] = ['title', 'date', 'author'];
  dataSource = new MatTableDataSource();

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  currentUser: any;
  data = [];
  mergedData: any;
  
  constructor(private router: Router ) {}

  ngOnInit() {
    
    this.data = JSON.parse(localStorage.getItem('blogs')) || [];
    this.currentUser=JSON.parse(localStorage.getItem('user'));
    this.dataSource.paginator = this.paginator;
    this.mergedData = this.data;
    this.dataSource =this.mergedData;
  }
  redirectToBlog(elem){
    localStorage.setItem('currentBlog',JSON.stringify(elem));
    this.router.navigate(['/viewblog']);
  }
}
