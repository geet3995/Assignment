import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-blog',
  templateUrl: './view-blog.component.html',
  styleUrls: ['./view-blog.component.css']
})
export class ViewBlogComponent implements OnInit {

  constructor() { }
  currentUser:any;
  currentBlog = {};

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('user'));
    this.currentBlog = JSON.parse(localStorage.getItem('currentBlog'));
  }

}
