import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {
  title: any;
  content: any;
  currentUser: any;

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('user'));
  }

  Onsave() {
    var ObjVal = 
      {
        "title": this.title,
        'blog': this.content,
        'author': this.currentUser,
        'date':new Date()
      }
    console.log(ObjVal);
    let previousBlogs = [];
    previousBlogs = JSON.parse(localStorage.getItem('blogs')) || [];
    previousBlogs.push(ObjVal);
    localStorage.setItem('blogs', JSON.stringify(previousBlogs));

    this.router.navigate(['/home']);
  }
}
